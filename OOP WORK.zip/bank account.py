#PART 1
#BANK ACCOUNT STIMULATION
class BankAccount:
    def __init__(self, account_holder, balance=0.0):
        self.account_holder = account_holder
        self.balance = balance
        self.interest_rate = 0.05  # 5% interest rate

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"Deposited ${amount:.2f} to {self.account_holder}'s account.")
        else:
            print("Deposit amount must be positive.")

    def withdraw(self, amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
            print(f"Withdrew ${amount:.2f} from {self.account_holder}'s account.")
        else:
            print("Withdrawal amount must be positive and less than or equal to the balance.")

    def apply_interest(self):
        interest = self.balance * self.interest_rate
        self.balance += interest
        print(f"Applied interest of ${interest:.2f} to {self.account_holder}'s account.")

    def display_account_info(self):
        print(f"Account Holder: {self.account_holder}")
        print(f"Balance: ${self.balance:.2f}\n")


# Creating two bank accounts
account1 = BankAccount("Alice")
account2 = BankAccount("Bob")

# Performing deposits and withdrawals
account1.deposit(1000)
account1.withdraw(200)
account2.deposit(500)
account2.withdraw(100)

# Applying interest
account1.apply_interest()
account2.apply_interest()

# Displaying account information
account1.display_account_info()
account2.display_account_info()


