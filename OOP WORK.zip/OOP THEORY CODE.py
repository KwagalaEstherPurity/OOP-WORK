class Person:
    def __init__(self, name, age):  # Constructor
        self.name = name  # Set name attribute
        self.age = age    # Set age attribute
    
    def introduce(self):
        print(f"Hi, my name is {self.name} and I am {self.age} years old.")

# Creating a new Person object
person1 = Person("Alice", 30)

# Calling the introduce method
person1.introduce()


class Dog:
    species = "Canis lupus"  # Class variable (shared by all dogs)
    
    def __init__(self, name, age):
        self.name = name  # Instance variable (unique to each dog)
        self.age = age    # Instance variable (unique to each dog)

# Creating two Dog objects
dog1 = Dog("Buddy", 5)
dog2 = Dog("Max", 3)

# Accessing their variables
print(dog1.name, dog1.age, dog1.species)  # Output: Buddy 5 Canis lupus
print(dog2.name, dog2.age, dog2.species)  # Output: Max 3 Canis lupus

# Changing the class variable
Dog.species = "Canis familiaris"

# All dogs now have the updated class variable
print(dog1.species)  # Output: Canis familiaris
print(dog2.species)  # Output: Canis familiaris

# Changing an instance variable affects only that dog
dog1.age = 6
print(dog1.age)  # Output: 6
print(dog2.age)  # Output: 3 (unchanged)



class Dog:
    species = "Canis lupus"  # Class variable
    
    @classmethod
    def change_species(cls, new_species):
        cls.species = new_species  # Changes class variable for all instances

# Changing the species for all dogs
Dog.change_species("Canis familiaris")
print(Dog.species)  # Output: Canis familiaris


class MathOperations:
    @staticmethod
    def add(a, b):
        return a + b  # Simple function logic

# Using the static method
result = MathOperations.add(5, 3)
print(result)  # Output: 8


class Player:
    max_score = 100  # Class variable (shared by all players)
    
    def __init__(self, name, score):
        self.name = name  # Instance variable (unique to each player)
        self.score = score  # Instance variable (unique to each player)

# Creating two players
player1 = Player("Alice", 50)
player2 = Player("Bob", 70)

# Accessing class variable
print(Player.max_score)  # Output: 100

# Changing class variable for all players
Player.max_score = 200

# Now all players have the updated max score
print(player1.max_score)  # Output: 200
print(player2.max_score)  # Output: 200
